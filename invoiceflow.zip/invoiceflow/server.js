const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const DATA_DIR = path.join(__dirname, 'data');
const INDEX_FILE = path.join(DATA_DIR, '_index.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(INDEX_FILE)) fs.writeFileSync(INDEX_FILE, '[]');

app.use(express.json({ limit: '12mb' })); // large enough for PDF base64
app.use(express.static(path.join(__dirname, 'public')));

// ── helpers ──────────────────────────────────────────────────────────────────

function loadIndex() {
  return JSON.parse(fs.readFileSync(INDEX_FILE, 'utf8'));
}

function saveIndex(idx) {
  fs.writeFileSync(INDEX_FILE, JSON.stringify(idx, null, 2));
}

function invPath(id) {
  return path.join(DATA_DIR, `${id}.json`);
}

function loadInv(id) {
  const f = invPath(id);
  if (!fs.existsSync(f)) return null;
  return JSON.parse(fs.readFileSync(f, 'utf8'));
}

function saveInv(inv) {
  fs.writeFileSync(invPath(inv.id), JSON.stringify(inv, null, 2));
  const idx = loadIndex();
  const meta = {
    id: inv.id,
    filename: inv.filename,
    status: inv.status,
    code: inv.code || '',
    createdAt: inv.createdAt,
    approvedAt: inv.approvedAt || null,
  };
  const i = idx.findIndex(x => x.id === inv.id);
  if (i >= 0) idx[i] = meta; else idx.push(meta);
  saveIndex(idx);
}

// ── routes ───────────────────────────────────────────────────────────────────

// Create invoice
app.post('/api/invoices', (req, res) => {
  const { filename, pdfB64 } = req.body;
  if (!filename || !pdfB64) return res.status(400).json({ error: 'Missing filename or pdfB64' });

  const id = crypto.randomBytes(4).toString('hex').toUpperCase();
  const inv = {
    id,
    filename,
    pdfB64,
    status: 'pending_pm',
    code: '',
    pmSig: null,
    lpSig: null,
    createdAt: new Date().toISOString(),
    approvedAt: null,
  };
  saveInv(inv);
  res.json({ id, pmToken: `PM-${id}` });
});

// Get invoice by ID (strip PDF bytes for archive listing, include for task views)
app.get('/api/invoices', (_req, res) => {
  res.json(loadIndex());
});

app.get('/api/invoices/:id', (req, res) => {
  const inv = loadInv(req.params.id.toUpperCase());
  if (!inv) return res.status(404).json({ error: 'Invoice not found' });
  res.json(inv);
});

// PM signs
app.patch('/api/invoices/:id/pm', (req, res) => {
  const inv = loadInv(req.params.id.toUpperCase());
  if (!inv) return res.status(404).json({ error: 'Not found' });
  if (inv.status !== 'pending_pm') return res.status(409).json({ error: 'PM step already complete' });

  const { code, pmSig } = req.body;
  if (!code || !pmSig) return res.status(400).json({ error: 'Missing code or pmSig' });

  inv.code = code;
  inv.pmSig = pmSig;
  inv.status = 'pending_lp';
  saveInv(inv);
  res.json({ lpToken: `LP-${inv.id}` });
});

// LP signs
app.patch('/api/invoices/:id/lp', (req, res) => {
  const inv = loadInv(req.params.id.toUpperCase());
  if (!inv) return res.status(404).json({ error: 'Not found' });
  if (inv.status !== 'pending_lp') return res.status(409).json({ error: 'Not ready for LP signature' });

  const { lpSig } = req.body;
  if (!lpSig) return res.status(400).json({ error: 'Missing lpSig' });

  inv.lpSig = lpSig;
  inv.status = 'approved';
  inv.approvedAt = new Date().toISOString();
  saveInv(inv);
  res.json({ ok: true });
});

// ── start ─────────────────────────────────────────────────────────────────────

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n  InvoiceFlow running → http://localhost:${PORT}\n`);
});
